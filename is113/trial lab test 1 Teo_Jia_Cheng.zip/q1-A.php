<?php
/* 
Name:  Teo Jia Cheng
Email: jcteo.2018
*/

if (!isset($_POST["num1"]) || !isset($_POST["num2"]) || !isset($_POST["num3"]) || !isset($_POST["divisor"])) {
    echo "Start from <a href='q1-A.html'>q1-A.html</a>";
    exit();
}

function is_divisible_by($num, $n): bool
{
    return $num % $n == 0;
}

echo "<ul>";

for ($i = 1; $i <= 3; $i++) {
    $num = $_POST["num$i"];
    $div = $_POST["divisor"];

    $result = is_divisible_by($num, $div) ? "YES" : "NO";
    echo "<li>";
    echo $num . " is divisible by " . $div . ": " . $result;
    echo "</li>";
}

echo "</ul>";
?>

