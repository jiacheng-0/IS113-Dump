<!--
Name:  Teo Jia Cheng
Email: jcteo.2018
-->
<html>
<body>
    <form method='post' action='q2-display.php'>

        <input type="checkbox" value="apple" name="fruit[]" id="apple_">
        <label for="apple_">Apple</label>

        <input type="checkbox" value="orange" name="fruit[]" id="orange_">
        <label for="orange_">Orange</label>

        <input type="checkbox" value="pear" name="fruit[]" id="pear_">
        <label for="pear_">Pear</label>

        <br>
        <input type='submit'>
    </form>
</body>
</html>