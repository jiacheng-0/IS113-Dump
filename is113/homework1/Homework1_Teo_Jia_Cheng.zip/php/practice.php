<?php


// Given this associative array, complete Parts A, B, C
$student_grades = [
    'Kee Hock' => ['A+', 'A', 'B+', 'A-'],
    'Debbie' => ['A', 'B+', 'A-', 'A'],
    'Patrick' => ['B', 'C', 'F', 'B-']
];


//========================================
// Part A
// Your code goes here
echo "<h1>Part A</h1>";
echo "<table border='1'>
<tr>
    <th>Names</th>
    <th>Grades</th>
</tr>";
foreach ($student_grades as $stu => $grade_arr) {
    foreach ($grade_arr as $one_grade) {
        echo "    <tr>
                    <td>$stu</td>
                    <td>$one_grade</td>
                  </tr>";
    }
}
echo "</table>";
echo '<hr>';
//========================================
// Part B
// Your code goes here
echo "<h1>Part B</h1>";
echo "<table border='1'>
<tr>
    <th>Names</th>
    <th>Grades</th>
</tr>";
foreach ($student_grades as $stu => $grade_arr) {
    foreach ($grade_arr as $one_grade) {
        $style = "color: red; font-size: medium";
        if ($one_grade == 'A-') {
            $style = "color: green; font-size: large";
        } elseif ($one_grade == 'A+' || $one_grade == 'A') {
            $style = "color: blue; font-size: x-large";
        }

        echo "    <tr>
                    <td style='font-size: medium'>$stu</td>
                    <td style='$style'>$one_grade</td>
                  </tr>";
    }
}
echo "</table>";


echo '<hr>';


//========================================
// Part C
// Your code goes here
echo "<h1>Part C</h1>";

//foreach ($student_grades as $stu => $grade_arr) {
////    sizeof gets the length of an array
//    echo $stu . " " . sizeof($grade_arr) . "<br/>";
//}

echo "<table border='1'>
<tr>
    <th>Names</th>
    <th>Grades</th>
</tr>";
foreach ($student_grades as $stu => $grade_arr) {


    $red_style = "color: red; font-size: medium";
    $green_style = "color: green; font-size: large";
    $blue_style = "color: blue; font-size: x-large";

    $curr_style = $red_style;

    if ($grade_arr[0] == 'A-'){
        $curr_style = $green_style;
    }
    if ($grade_arr[0] == 'A' || $grade_arr[0] == 'A+'){
        $curr_style = $blue_style;
    }

    $rows_to_span = sizeof($grade_arr);
    echo "<tr>";
    echo "<td style='font-size: medium' rowspan='$rows_to_span'>$stu</td>";
    echo "<td style='$curr_style'>$grade_arr[0]</td>";
    echo "</tr>";

    for ($i = 1; $i < $rows_to_span; $i++) {

        $curr_style = $red_style;
        if ($grade_arr[$i] == 'A-'){
            $curr_style = $green_style;
        } elseif ($grade_arr[$i] == 'A' || $grade_arr[$i] == 'A+'){
            $curr_style = $blue_style;
        }
        echo "<tr>";
        echo "<td style='$curr_style'>$grade_arr[$i]</td>";
        echo "</tr>";
    }
}
echo "</table>";
echo '<hr>';
