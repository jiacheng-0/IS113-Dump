<!--
    Name:  Teo Jia Cheng
    Email: jcteo.2018
-->

<?php

// Write your codes in the following

$name = $_POST['name'] ?? "";

echo "Dear $name, Thank you for subscribing to SIS Newsletter!";

?>